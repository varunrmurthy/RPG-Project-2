﻿
Please use legal way to get game files before use this pack.

Usage:
Put XXX.cia and XXX.3ds games, DLC & Patch to this folder, support multi-files.
Run "Batch CIA 3DS Decryptor.bat".
Then waiting it finished. (It will take a lot of memory/ram when these files are too big.)

Features & Effects:
One key batch decrypt CIA & 3DS files.
DLC/Patch CIA > Decrypted CIA, able to install in Citra.
3DS Games > Decrypted and trimmed 3DS, so it is smaller.
CIA Games > Decrypted CCI (NCSD), not CXI (NCCH).
Auto detect CIA type (DLC/Patch/Game).

Authors:
54634564 - decrypt.exe
profi200 - makerom.exe, ctrtool.exe
matif - Batch CIA 3DS Decryptor.bat





